export function FirstBg() {
  return <div></div>;
}
