export default function Page() {
  return <div>Comment Section is AVAILABLE HERE!</div>;
}
