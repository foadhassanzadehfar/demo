export default function Page() {
  return (
    <div className="h-screen flex items-center justify-center">
      <h2>Dashboard Main Page</h2>
    </div>
  );
}
