export default function Page() {
  return <h1>Dashboard Account</h1>;
}
